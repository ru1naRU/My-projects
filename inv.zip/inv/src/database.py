import sqlite3
import time
import secrets

def init_db():
    conn = sqlite3.connect('data/inventory.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            quantity INTEGER NOT NULL
        )
    ''')
    c.execute('''
        CREATE TABLE IF NOT EXISTS admin_tokens (
            token TEXT PRIMARY KEY,
            created_at INTEGER,
            expires_at INTEGER
        )
    ''')
    conn.commit()
    conn.close()

def generate_token():
    token = secrets.token_urlsafe(16)
    expires_at = int(time.time()) + 3600  # Token expires in 1 hour
    conn = sqlite3.connect('data/inventory.db')
    c = conn.cursor()
    c.execute('''
        INSERT INTO admin_tokens (token, created_at, expires_at)
        VALUES (?, ?, ?)
    ''', (token, int(time.time()), expires_at))
    conn.commit()
    conn.close()
    return token

def is_valid_token(token):
    conn = sqlite3.connect('data/inventory.db')
    c = conn.cursor()
    c.execute('''
        SELECT * FROM admin_tokens WHERE token = ? AND expires_at > ?
    ''', (token, int(time.time())))
    result = c.fetchone()
    conn.close()
    return result is not None

def add_item(name, item_type, damage, hit_chance, heal_amount):
    print(f"Adding item: {name}, {item_type}, {damage}, {hit_chance}, {heal_amount}")
    conn = sqlite3.connect('data/inventory.db')
    c = conn.cursor()
    c.execute('''
        INSERT INTO items (name, description, quantity)
        VALUES (?, ?, ?)
    ''', (name, f"Type: {item_type}, Damage: {damage}, Hit Chance: {hit_chance}, Heal Amount: {heal_amount}", 1))
    conn.commit()
    conn.close()
