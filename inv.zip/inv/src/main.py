import sys
import os

# Add the parent directory of web_admin_panel to the Python path
sys.path.append(os.path.abspath('.'))

import threading
from web_admin_panel.app import app

import discord
from commands import bot

def run_flask_app():
    app.run(debug=True, use_reloader=False)

if __name__ == '__main__':
    # Start Flask app in a separate thread
    flask_thread = threading.Thread(target=run_flask_app)
    flask_thread.start()

    # Start Discord bot
    bot.run('')
