import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

import discord
from discord.ext import commands
from database import init_db, generate_token

intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(command_prefix='!', intents=intents)

@bot.event
async def on_ready():
    print(f'Logged in as {bot.user.name}')
    init_db()
    print("on_ready event triggered")

@bot.command()
async def create_item(ctx, name: str, description: str, quantity: int):
    # Implementation for creating an item
    print(f"create_item command called with name: {name}, description: {description}, quantity: {quantity}")
    pass

@bot.command()
async def list_items(ctx):
    # Implementation for listing items
    print("list_items command called")
    pass

@bot.command()
async def admin_panel(ctx):
    if ctx.author.id != 1255213325101301861:
        await ctx.send("You do not have permission to use this command.")
        print("admin_panel command denied")
        return

    token = generate_token()
    admin_url = f'http://127.0.0.1:5000/admin?token={token}'
    await ctx.author.send(f'Here is your admin panel link: {admin_url}')
    await ctx.send('Admin panel link sent to your DMs.')
    print("admin_panel command executed")
