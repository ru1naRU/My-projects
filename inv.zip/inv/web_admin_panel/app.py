from flask import Flask, render_template, request, redirect, url_for
from src.database import init_db, is_valid_token, add_item

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('admin_panel.html')

@app.route('/admin')
def admin_panel():
    token = request.args.get('token')
    if not token or not is_valid_token(token):
        return "Invalid or expired token", 403
    return render_template('admin_panel.html')

@app.route('/add_item', methods=['POST'])
def add_item():
    print("Adding item in app.py")
    name = request.form['item_name']
    item_type = request.form['item_type']
    damage = request.form.get('damage', 0, type=int)
    hit_chance = request.form.get('hit_chance', 0, type=int)
    heal_amount = request.form.get('heal_amount', 0, type=int)
    add_item(name, item_type, damage, hit_chance, heal_amount)
    return redirect(url_for('admin_panel'))

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
