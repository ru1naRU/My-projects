import os
import discord
from discord.ext import commands
from dotenv import load_dotenv
from modules.database import Database
from modules.rpg import RPGSystem
from modules.combat import CombatSystem
from modules.economy import EconomySystem
from modules.inventory import InventorySystem
from modules.quests import QuestSystem
from modules.skills import SkillSystem

# Load environment variables
load_dotenv()

# Bot configuration
intents = discord.Intents.all()
bot = commands.Bot(command_prefix='!', intents=intents)

# Initialize systems
db = None
rpg_system = None
combat_system = None
economy_system = None
inventory_system = None
quest_system = None
skill_system = None

@bot.event
async def on_ready():
    global db, rpg_system, combat_system, economy_system, inventory_system, quest_system, skill_system
    
    print(f'{bot.user} has connected to Discord!')
    
    # Initialize database
    db = Database()
    await db.initialize()
    
    # Initialize all systems
    rpg_system = RPGSystem(db)
    combat_system = CombatSystem(db)
    economy_system = EconomySystem(db)
    inventory_system = InventorySystem(db)
    quest_system = QuestSystem(db)
    skill_system = SkillSystem(db)
    
    # Sync slash commands
    await bot.tree.sync()

# Character Commands
@bot.hybrid_command(name="create_character", description="Create your RPG character. Example: !create_character John Warrior")
async def create_character(ctx, name: str, class_type: str):
    await rpg_system.create_character(ctx, name, class_type)

@bot.hybrid_command(name="profile", description="View your character profile")
async def profile(ctx):
    await rpg_system.show_profile(ctx)

# Combat Commands
@bot.hybrid_command(name="attack", description="Attack another player or monster")
async def attack(ctx, target: discord.Member):
    await combat_system.initiate_combat(ctx, target)

@bot.hybrid_command(name="use_skill", description="Use a combat skill")
async def use_skill(ctx, skill_name: str, target: discord.Member = None):
    await combat_system.use_skill(ctx, skill_name, target)

# Economy Commands
@bot.hybrid_command(name="balance", description="Check your balance")
async def balance(ctx):
    await economy_system.show_balance(ctx)

@bot.hybrid_command(name="shop", description="View the item shop")
async def shop(ctx):
    await economy_system.show_shop(ctx)

@bot.hybrid_command(name="buy", description="Buy an item from the shop")
async def buy(ctx, item_name: str):
    await economy_system.buy_item(ctx, item_name)

# Inventory Commands
@bot.hybrid_command(name="inventory", description="View your inventory")
async def inventory(ctx):
    await inventory_system.show_inventory(ctx)

@bot.hybrid_command(name="equip", description="Equip an item")
async def equip(ctx, item_name: str):
    await inventory_system.equip_item(ctx, item_name)

# Quest Commands
@bot.hybrid_command(name="quests", description="View available quests")
async def quests(ctx):
    await quest_system.show_quests(ctx)

@bot.hybrid_command(name="accept_quest", description="Accept a quest")
async def accept_quest(ctx, quest_id: int):
    await quest_system.accept_quest(ctx, quest_id)

# Skill Commands
@bot.hybrid_command(name="skills", description="View your skills")
async def skills(ctx):
    await skill_system.show_skills(ctx)

@bot.hybrid_command(name="learn_skill", description="Learn a new skill")
async def learn_skill(ctx, skill_name: str):
    await skill_system.learn_skill(ctx, skill_name)

if __name__ == "__main__":
    bot.run(os.getenv('DISCORD_TOKEN'))
