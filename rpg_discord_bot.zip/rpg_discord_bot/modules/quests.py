import discord
from discord.ext import commands
from typing import List, Dict, Optional

class Quest:
    def __init__(self, quest_id: int, name: str, description: str, requirements: str, rewards: str, difficulty: str):
        self.quest_id = quest_id
        self.name = name
        self.description = description
        self.requirements = requirements
        self.rewards = rewards
        self.difficulty = difficulty

class QuestSystem:
    def __init__(self, db):
        self.db = db
        self.quests: List[Quest] = []
        self.load_quests()

    def load_quests(self):
        """Load quests from the database"""
        # Sample quests for demonstration
        self.quests.append(Quest(1, "Slay the Dragon", "Defeat the dragon terrorizing the village.", "Level 5", "1000 XP, 500 Gold", "Hard"))
        self.quests.append(Quest(2, "Collect Herbs", "Gather 10 healing herbs from the forest.", "None", "200 XP, Health Potion", "Easy"))
        self.quests.append(Quest(3, "Rescue the Princess", "Save the princess from the evil sorcerer.", "Level 10", "1500 XP, Enchanted Bow", "Very Hard"))

    async def show_quests(self, ctx: commands.Context):
        """Display available quests"""
        embed = discord.Embed(
            title="🗺️ Available Quests",
            description="Here are the quests you can undertake:",
            color=discord.Color.gold()
        )

        for quest in self.quests:
            embed.add_field(
                name=quest.name,
                value=f"**Description:** {quest.description}\n**Requirements:** {quest.requirements}\n**Rewards:** {quest.rewards}\n**Difficulty:** {quest.difficulty}",
                inline=False
            )

        await ctx.send(embed=embed)

    async def accept_quest(self, ctx: commands.Context, quest_id: int):
        """Accept a quest"""
        quest = next((q for q in self.quests if q.quest_id == quest_id), None)
        if not quest:
            await ctx.send("Quest not found!")
            return

        # Check if the user already has an active quest
        active_quest = await self.db.get_active_quest(ctx.author.id)
        if active_quest:
            await ctx.send("You already have an active quest! Complete it before accepting a new one.")
            return

        # Add the quest to the active quests in the database
        await self.db.add_active_quest(ctx.author.id, quest.quest_id)

        embed = discord.Embed(
            title="Quest Accepted!",
            description=f"You have accepted the quest: **{quest.name}**",
            color=discord.Color.green()
        )
        await ctx.send(embed=embed)

    async def complete_quest(self, ctx: commands.Context, quest_id: int):
        """Complete a quest"""
        active_quest = await self.db.get_active_quest(ctx.author.id)
        if not active_quest or active_quest['quest_id'] != quest_id:
            await ctx.send("You don't have this quest active!")
            return

        # Reward the user
        rewards = active_quest['rewards'].split(',')
        for reward in rewards:
            if reward.strip().endswith("XP"):
                xp_amount = int(reward.strip().replace("XP", "").strip())
                await self.db.update_character(ctx.author.id, experience=xp_amount)
            elif reward.strip().endswith("Gold"):
                gold_amount = int(reward.strip().replace("Gold", "").strip())
                await self.db.update_balance(ctx.author.id, gold_amount)

        # Remove the quest from active quests
        await self.db.remove_active_quest(ctx.author.id)

        embed = discord.Embed(
            title="Quest Completed!",
            description=f"You have completed the quest: **{active_quest['name']}**",
            color=discord.Color.blue()
        )
        await ctx.send(embed=embed)
