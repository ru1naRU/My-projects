import discord
from discord.ext import commands
import random
from datetime import datetime, timedelta
from typing import Dict, List, Optional

class EconomySystem:
    def __init__(self, db):
        self.db = db
        self.shop_items = {
            # Weapons
            "iron_sword": {
                "name": "Iron Sword",
                "type": "weapon",
                "price": 500,
                "rarity": "common",
                "stats": {
                    "strength": 5,
                    "damage": "10-15"
                },
                "description": "A basic iron sword"
            },
            "enchanted_bow": {
                "name": "Enchanted Bow",
                "type": "weapon",
                "price": 1000,
                "rarity": "rare",
                "stats": {
                    "dexterity": 8,
                    "damage": "15-20"
                },
                "description": "A bow imbued with magical energy"
            },
            "mystic_staff": {
                "name": "Mystic Staff",
                "type": "weapon",
                "price": 1000,
                "rarity": "rare",
                "stats": {
                    "intelligence": 8,
                    "mana": 20
                },
                "description": "A staff crackling with arcane power"
            },
            
            # Armor
            "leather_armor": {
                "name": "Leather Armor",
                "type": "armor",
                "price": 300,
                "rarity": "common",
                "stats": {
                    "defense": 5,
                    "health": 20
                },
                "description": "Basic leather armor"
            },
            "chainmail": {
                "name": "Chainmail",
                "type": "armor",
                "price": 800,
                "rarity": "uncommon",
                "stats": {
                    "defense": 10,
                    "health": 40
                },
                "description": "Flexible chainmail armor"
            },
            "plate_armor": {
                "name": "Plate Armor",
                "type": "armor",
                "price": 2000,
                "rarity": "rare",
                "stats": {
                    "defense": 20,
                    "health": 100
                },
                "description": "Heavy plate armor"
            },
            
            # Consumables
            "health_potion": {
                "name": "Health Potion",
                "type": "consumable",
                "price": 100,
                "rarity": "common",
                "stats": {
                    "heal": 50
                },
                "description": "Restores 50 HP"
            },
            "mana_potion": {
                "name": "Mana Potion",
                "type": "consumable",
                "price": 100,
                "rarity": "common",
                "stats": {
                    "mana": 30
                },
                "description": "Restores 30 Mana"
            },
            "strength_elixir": {
                "name": "Strength Elixir",
                "type": "consumable",
                "price": 500,
                "rarity": "uncommon",
                "stats": {
                    "strength": 5,
                    "duration": "1h"
                },
                "description": "Temporarily increases strength"
            }
        }
        
        # Rarity colors for embeds
        self.rarity_colors = {
            "common": discord.Color.light_grey(),
            "uncommon": discord.Color.green(),
            "rare": discord.Color.blue(),
            "epic": discord.Color.purple(),
            "legendary": discord.Color.gold()
        }

    async def show_balance(self, ctx: commands.Context):
        """Display user's balance"""
        balance = await self.db.get_balance(ctx.author.id)
        if not balance:
            await ctx.send("You don't have a character! Use !create_character to create one.")
            return

        embed = discord.Embed(
            title="💰 Balance",
            color=discord.Color.gold()
        )
        embed.add_field(name="Gold", value=f"{balance[0]:,}", inline=True)
        embed.add_field(name="Bank", value=f"{balance[1]:,}", inline=True)
        
        await ctx.send(embed=embed)

    async def show_shop(self, ctx: commands.Context, category: str = None):
        """Display the item shop"""
        embed = discord.Embed(
            title="🏪 Item Shop",
            description="Welcome to the shop! Use !buy <item_name> to purchase an item.",
            color=discord.Color.blue()
        )

        # Filter items by category if specified
        items = self.shop_items
        if category:
            items = {k: v for k, v in items.items() if v['type'] == category.lower()}

        # Group items by type
        weapons = []
        armor = []
        consumables = []

        for item_id, item in items.items():
            item_text = f"**{item['name']}** - {item['price']}g\n{item['description']}\n"
            
            # Add stats to description
            stats_text = ", ".join([f"{k}: {v}" for k, v in item['stats'].items()])
            item_text += f"*Stats: {stats_text}*\n"
            
            if item['type'] == 'weapon':
                weapons.append(item_text)
            elif item['type'] == 'armor':
                armor.append(item_text)
            else:
                consumables.append(item_text)

        if weapons:
            embed.add_field(name="⚔️ Weapons", value="\n".join(weapons), inline=False)
        if armor:
            embed.add_field(name="🛡️ Armor", value="\n".join(armor), inline=False)
        if consumables:
            embed.add_field(name="🧪 Consumables", value="\n".join(consumables), inline=False)

        await ctx.send(embed=embed)

    async def buy_item(self, ctx: commands.Context, item_name: str):
        """Purchase an item from the shop"""
        # Convert item name to shop key format
        item_key = item_name.lower().replace(' ', '_')
        
        if item_key not in self.shop_items:
            await ctx.send("Invalid item name! Use !shop to see available items.")
            return
        
        item = self.shop_items[item_key]
        
        # Check if user has enough gold
        balance = await self.db.get_balance(ctx.author.id)
        if not balance or balance[0] < item['price']:
            await ctx.send("You don't have enough gold!")
            return
        
        # Add item to inventory
        # First, add item to items table if not exists
        async with self.db.db_name as db:
            cursor = await db.execute(
                '''
                INSERT OR IGNORE INTO items (name, type, rarity, stats, price, description)
                VALUES (?, ?, ?, ?, ?, ?)
                ''',
                (item['name'], item['type'], item['rarity'], str(item['stats']), item['price'], item['description'])
            )
            item_id = cursor.lastrowid
            
            # Add to inventory
            await self.db.add_item(ctx.author.id, item_id)
            
            # Deduct gold
            await self.db.update_balance(ctx.author.id, -item['price'])
            
            await db.commit()
        
        embed = discord.Embed(
            title="🛍️ Item Purchased!",
            description=f"You bought {item['name']} for {item['price']} gold!",
            color=self.rarity_colors[item['rarity']]
        )
        
        # Add item stats to embed
        stats_text = "\n".join([f"{k.capitalize()}: {v}" for k, v in item['stats'].items()])
        embed.add_field(name="Stats", value=stats_text)
        
        await ctx.send(embed=embed)

    async def daily_reward(self, ctx: commands.Context):
        """Claim daily reward"""
        # Get last daily claim time
        async with self.db.db_name as db:
            cursor = await db.execute(
                'SELECT last_daily FROM economy WHERE user_id = ?',
                (ctx.author.id,)
            )
            result = await cursor.fetchone()
            
            if not result:
                await ctx.send("You don't have a character! Use !create_character to create one.")
                return
            
            last_daily = result[0]
            
            if last_daily:
                last_claim = datetime.fromisoformat(last_daily)
                if datetime.now() - last_claim < timedelta(days=1):
                    next_claim = last_claim + timedelta(days=1)
                    time_left = next_claim - datetime.now()
                    hours = time_left.seconds // 3600
                    minutes = (time_left.seconds % 3600) // 60
                    await ctx.send(f"You can claim your next daily reward in {hours}h {minutes}m!")
                    return
            
            # Calculate reward (base + random bonus)
            base_reward = 100
            bonus = random.randint(50, 150)
            total_reward = base_reward + bonus
            
            # Update balance and last claim time
            await db.execute(
                '''
                UPDATE economy 
                SET gold = gold + ?, last_daily = ?
                WHERE user_id = ?
                ''',
                (total_reward, datetime.now().isoformat(), ctx.author.id)
            )
            await db.commit()
            
            embed = discord.Embed(
                title="📅 Daily Reward!",
                description=f"You received {total_reward} gold!\n(Base: {base_reward} + Bonus: {bonus})",
                color=discord.Color.gold()
            )
            
            await ctx.send(embed=embed)

    async def transfer_gold(self, ctx: commands.Context, amount: int, target: discord.Member):
        """Transfer gold to another player"""
        if amount <= 0:
            await ctx.send("Amount must be positive!")
            return
            
        if target.id == ctx.author.id:
            await ctx.send("You can't transfer gold to yourself!")
            return
            
        # Check if both users have characters
        sender_balance = await self.db.get_balance(ctx.author.id)
        if not sender_balance:
            await ctx.send("You don't have a character!")
            return
            
        target_char = await self.db.get_character(target.id)
        if not target_char:
            await ctx.send("Target player doesn't have a character!")
            return
            
        # Check if sender has enough gold
        if sender_balance[0] < amount:
            await ctx.send("You don't have enough gold!")
            return
            
        # Perform transfer
        await self.db.update_balance(ctx.author.id, -amount)
        await self.db.update_balance(target.id, amount)
        
        embed = discord.Embed(
            title="💸 Gold Transfer",
            description=f"Successfully transferred {amount} gold to {target.display_name}!",
            color=discord.Color.green()
        )
        
        await ctx.send(embed=embed)
