import aiosqlite
import json

class Database:
    def __init__(self):
        self.db_name = "rpg_database.db"

    async def initialize(self):
        """Initialize all necessary database tables"""
        async with aiosqlite.connect(self.db_name) as db:
            # Characters table
            await db.execute('''
                CREATE TABLE IF NOT EXISTS characters (
                    user_id INTEGER PRIMARY KEY,
                    name TEXT,
                    class_type TEXT,
                    level INTEGER DEFAULT 1,
                    experience INTEGER DEFAULT 0,
                    health INTEGER DEFAULT 100,
                    max_health INTEGER DEFAULT 100,
                    mana INTEGER DEFAULT 50,
                    max_mana INTEGER DEFAULT 50,
                    strength INTEGER DEFAULT 10,
                    dexterity INTEGER DEFAULT 10,
                    intelligence INTEGER DEFAULT 10,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')

            # Inventory table
            await db.execute('''
                CREATE TABLE IF NOT EXISTS inventory (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    item_id INTEGER,
                    quantity INTEGER DEFAULT 1,
                    equipped BOOLEAN DEFAULT 0,
                    FOREIGN KEY (user_id) REFERENCES characters(user_id)
                )
            ''')

            # Items table
            await db.execute('''
                CREATE TABLE IF NOT EXISTS items (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT,
                    type TEXT,
                    rarity TEXT,
                    stats TEXT,
                    price INTEGER,
                    description TEXT
                )
            ''')

            # Skills table
            await db.execute('''
                CREATE TABLE IF NOT EXISTS skills (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    name TEXT,
                    level INTEGER DEFAULT 1,
                    experience INTEGER DEFAULT 0,
                    FOREIGN KEY (user_id) REFERENCES characters(user_id)
                )
            ''')

            # Quests table
            await db.execute('''
                CREATE TABLE IF NOT EXISTS quests (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT,
                    description TEXT,
                    requirements TEXT,
                    rewards TEXT,
                    difficulty TEXT
                )
            ''')

            # Active quests table
            await db.execute('''
                CREATE TABLE IF NOT EXISTS active_quests (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    quest_id INTEGER,
                    progress TEXT,
                    status TEXT DEFAULT 'in_progress',
                    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES characters(user_id),
                    FOREIGN KEY (quest_id) REFERENCES quests(id)
                )
            ''')

            # Economy table
            await db.execute('''
                CREATE TABLE IF NOT EXISTS economy (
                    user_id INTEGER PRIMARY KEY,
                    gold INTEGER DEFAULT 0,
                    bank INTEGER DEFAULT 0,
                    last_daily TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES characters(user_id)
                )
            ''')

            await db.commit()

    async def create_character(self, user_id: int, name: str, class_type: str):
        """Create a new character for a user"""
        async with aiosqlite.connect(self.db_name) as db:
            await db.execute(
                'INSERT INTO characters (user_id, name, class_type) VALUES (?, ?, ?)',
                (user_id, name, class_type)
            )
            await db.execute(
                'INSERT INTO economy (user_id) VALUES (?)',
                (user_id,)
            )
            await db.commit()

    async def get_character(self, user_id: int):
        """Get character data for a user"""
        async with aiosqlite.connect(self.db_name) as db:
            async with db.execute(
                'SELECT * FROM characters WHERE user_id = ?',
                (user_id,)
            ) as cursor:
                return await cursor.fetchone()

    async def update_character(self, user_id: int, **kwargs):
        """Update character attributes"""
        if not kwargs:
            return
        
        query = 'UPDATE characters SET '
        query += ', '.join(f'{key} = ?' for key in kwargs.keys())
        query += ' WHERE user_id = ?'
        
        values = list(kwargs.values())
        values.append(user_id)
        
        async with aiosqlite.connect(self.db_name) as db:
            await db.execute(query, values)
            await db.commit()

    async def add_item(self, user_id: int, item_id: int, quantity: int = 1):
        """Add an item to user's inventory"""
        async with aiosqlite.connect(self.db_name) as db:
            await db.execute(
                'INSERT INTO inventory (user_id, item_id, quantity) VALUES (?, ?, ?)',
                (user_id, item_id, quantity)
            )
            await db.commit()

    async def get_inventory(self, user_id: int):
        """Get user's inventory"""
        async with aiosqlite.connect(self.db_name) as db:
            async with db.execute(
                '''
                SELECT i.*, it.name, it.type, it.rarity, it.stats 
                FROM inventory i 
                JOIN items it ON i.item_id = it.id 
                WHERE i.user_id = ?
                ''',
                (user_id,)
            ) as cursor:
                return await cursor.fetchall()

    async def update_balance(self, user_id: int, amount: int):
        """Update user's balance"""
        async with aiosqlite.connect(self.db_name) as db:
            await db.execute(
                'UPDATE economy SET gold = gold + ? WHERE user_id = ?',
                (amount, user_id)
            )
            await db.commit()

    async def get_balance(self, user_id: int):
        """Get user's balance"""
        async with aiosqlite.connect(self.db_name) as db:
            async with db.execute(
                'SELECT gold, bank FROM economy WHERE user_id = ?',
                (user_id,)
            ) as cursor:
                return await cursor.fetchone()
