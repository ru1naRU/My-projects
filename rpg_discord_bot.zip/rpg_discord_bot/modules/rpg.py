import discord
from discord.ext import commands
import json
from typing import Dict, Optional

class Character:
    def __init__(self, user_id: int, name: str, class_type: str):
        self.user_id = user_id
        self.name = name
        self.class_type = class_type
        self.level = 1
        self.experience = 0
        self.health = 100
        self.max_health = 100
        self.mana = 50
        self.max_mana = 50
        
        # Base stats based on class
        if class_type.lower() == "warrior":
            self.strength = 15
            self.dexterity = 10
            self.intelligence = 5
        elif class_type.lower() == "archer":
            self.strength = 8
            self.dexterity = 15
            self.intelligence = 7
        elif class_type.lower() == "mage":
            self.strength = 5
            self.dexterity = 8
            self.intelligence = 17
        else:
            self.strength = 10
            self.dexterity = 10
            self.intelligence = 10

class RPGSystem:
    def __init__(self, db):
        self.db = db
        self.available_classes = ["warrior", "archer", "mage"]
        self.level_exp_requirements = {
            1: 100,
            2: 250,
            3: 500,
            4: 1000,
            5: 2000,
            # Add more levels as needed
        }

    async def create_character(self, ctx: commands.Context, name: str, class_type: str):
        """Create a new character for a user"""
        if len(name) > 32:
            await ctx.send("Character name must be 32 characters or less!")
            return

        class_type = class_type.lower()
        if class_type not in self.available_classes:
            await ctx.send(f"Invalid class! Available classes: {', '.join(self.available_classes)}")
            return

        # Check if character already exists
        existing_char = await self.db.get_character(ctx.author.id)
        if existing_char:
            await ctx.send("You already have a character! Use !profile to view it.")
            return

        # Create character
        character = Character(ctx.author.id, name, class_type)
        await self.db.create_character(
            ctx.author.id,
            name,
            class_type
        )

        embed = discord.Embed(
            title="Character Created!",
            description=f"Welcome, {name} the {class_type.capitalize()}!",
            color=discord.Color.green()
        )
        embed.add_field(name="Health", value=f"{character.health}/{character.max_health}")
        embed.add_field(name="Mana", value=f"{character.mana}/{character.max_mana}")
        embed.add_field(name="Level", value=character.level)
        embed.add_field(name="Strength", value=character.strength)
        embed.add_field(name="Dexterity", value=character.dexterity)
        embed.add_field(name="Intelligence", value=character.intelligence)

        await ctx.send(embed=embed)

    async def show_profile(self, ctx: commands.Context):
        """Display character profile"""
        character = await self.db.get_character(ctx.author.id)
        if not character:
            await ctx.send("You don't have a character yet! Use !create_character to create one.")
            return

        # Convert tuple to dict for easier access
        char_dict = {
            "user_id": character[0],
            "name": character[1],
            "class_type": character[2],
            "level": character[3],
            "experience": character[4],
            "health": character[5],
            "max_health": character[6],
            "mana": character[7],
            "max_mana": character[8],
            "strength": character[9],
            "dexterity": character[10],
            "intelligence": character[11]
        }

        embed = discord.Embed(
            title=f"{char_dict['name']}'s Profile",
            description=f"Level {char_dict['level']} {char_dict['class_type'].capitalize()}",
            color=discord.Color.blue()
        )

        # Add character stats
        embed.add_field(
            name="Health",
            value=f"{char_dict['health']}/{char_dict['max_health']}",
            inline=True
        )
        embed.add_field(
            name="Mana",
            value=f"{char_dict['mana']}/{char_dict['max_mana']}",
            inline=True
        )
        embed.add_field(
            name="Experience",
            value=f"{char_dict['experience']}/{self.level_exp_requirements.get(char_dict['level'], 'MAX')}",
            inline=True
        )

        # Add base stats
        embed.add_field(name="Strength", value=char_dict['strength'], inline=True)
        embed.add_field(name="Dexterity", value=char_dict['dexterity'], inline=True)
        embed.add_field(name="Intelligence", value=char_dict['intelligence'], inline=True)

        # Get inventory summary
        inventory = await self.db.get_inventory(ctx.author.id)
        if inventory:
            equipped_items = [item for item in inventory if item[4]]  # item[4] is the equipped status
            inventory_summary = "\n".join([f"{item[5]} (Equipped)" for item in equipped_items])
            if inventory_summary:
                embed.add_field(name="Equipped Items", value=inventory_summary, inline=False)

        # Get balance
        balance = await self.db.get_balance(ctx.author.id)
        if balance:
            embed.add_field(name="Gold", value=f"{balance[0]:,}", inline=True)
            embed.add_field(name="Bank", value=f"{balance[1]:,}", inline=True)

        await ctx.send(embed=embed)

    async def gain_experience(self, ctx: commands.Context, amount: int):
        """Award experience to a character and handle leveling up"""
        character = await self.db.get_character(ctx.author.id)
        if not character:
            return

        char_dict = {
            "level": character[3],
            "experience": character[4]
        }

        new_exp = char_dict["experience"] + amount
        level = char_dict["level"]
        level_requirement = self.level_exp_requirements.get(level, float('inf'))

        # Check for level up
        if new_exp >= level_requirement:
            # Level up!
            new_level = level + 1
            await self.db.update_character(
                ctx.author.id,
                level=new_level,
                experience=new_exp - level_requirement
            )

            # Increase stats based on class
            class_type = character[2].lower()
            if class_type == "warrior":
                str_increase = 3
                dex_increase = 2
                int_increase = 1
            elif class_type == "archer":
                str_increase = 2
                dex_increase = 3
                int_increase = 1
            else:  # mage
                str_increase = 1
                dex_increase = 2
                int_increase = 3

            await self.db.update_character(
                ctx.author.id,
                strength=character[9] + str_increase,
                dexterity=character[10] + dex_increase,
                intelligence=character[11] + int_increase,
                max_health=character[6] + 10,
                max_mana=character[8] + 5,
                health=character[6] + 10,
                mana=character[8] + 5
            )

            embed = discord.Embed(
                title="Level Up!",
                description=f"Congratulations! You've reached level {new_level}!",
                color=discord.Color.gold()
            )
            embed.add_field(name="Strength Increase", value=f"+{str_increase}")
            embed.add_field(name="Dexterity Increase", value=f"+{dex_increase}")
            embed.add_field(name="Intelligence Increase", value=f"+{int_increase}")
            embed.add_field(name="Health Increase", value="+10")
            embed.add_field(name="Mana Increase", value="+5")

            await ctx.send(embed=embed)
        else:
            # Just update experience
            await self.db.update_character(ctx.author.id, experience=new_exp)
            await ctx.send(f"You gained {amount} experience points!")
