import discord
from discord.ext import commands
import random
import asyncio
from typing import Dict, List, Optional, Tuple

class CombatSystem:
    def __init__(self, db):
        self.db = db
        self.active_battles: Dict[int, 'Battle'] = {}  # user_id: Battle
        
        # Define base damage for each class
        self.class_damage = {
            "warrior": {"min": 15, "max": 25},
            "archer": {"min": 12, "max": 20},
            "mage": {"min": 10, "max": 30}
        }
        
        # Define skills for each class
        self.class_skills = {
            "warrior": {
                "heavy_strike": {
                    "damage_mult": 1.5,
                    "mana_cost": 20,
                    "description": "A powerful strike dealing 150% damage"
                },
                "shield_bash": {
                    "damage_mult": 0.8,
                    "stun_chance": 0.3,
                    "mana_cost": 25,
                    "description": "Bash with your shield, dealing 80% damage with a 30% chance to stun"
                },
                "battle_cry": {
                    "buff_mult": 1.2,
                    "duration": 3,
                    "mana_cost": 30,
                    "description": "Increase damage by 20% for 3 turns"
                }
            },
            "archer": {
                "precise_shot": {
                    "damage_mult": 1.3,
                    "crit_chance": 0.4,
                    "mana_cost": 15,
                    "description": "A precise shot with 40% critical hit chance"
                },
                "volley": {
                    "damage_mult": 0.7,
                    "hits": 3,
                    "mana_cost": 25,
                    "description": "Fire 3 arrows dealing 70% damage each"
                },
                "poison_arrow": {
                    "damage_mult": 0.8,
                    "dot_damage": 10,
                    "duration": 3,
                    "mana_cost": 30,
                    "description": "Apply poison dealing damage over time"
                }
            },
            "mage": {
                "fireball": {
                    "damage_mult": 1.4,
                    "mana_cost": 30,
                    "description": "Launch a powerful fireball"
                },
                "ice_shard": {
                    "damage_mult": 0.9,
                    "slow_chance": 0.4,
                    "mana_cost": 25,
                    "description": "Launch an ice shard with chance to slow"
                },
                "lightning_bolt": {
                    "damage_mult": 1.2,
                    "chain_chance": 0.3,
                    "mana_cost": 35,
                    "description": "Cast lightning with chance to chain"
                }
            }
        }

    class Battle:
        def __init__(self, player1, player2, is_pvp=True):
            self.player1 = player1
            self.player2 = player2
            self.is_pvp = is_pvp
            self.current_turn = player1
            self.turn_count = 0
            self.status_effects = {
                player1.id: {},
                player2.id: {}
            }

    async def calculate_damage(self, attacker_stats: dict, defender_stats: dict, skill: Optional[dict] = None) -> Tuple[int, bool]:
        """Calculate damage for an attack"""
        # Get base damage for attacker's class
        base_damage = random.randint(
            self.class_damage[attacker_stats['class_type']]['min'],
            self.class_damage[attacker_stats['class_type']]['max']
        )
        
        # Apply strength bonus
        damage = base_damage * (1 + (attacker_stats['strength'] * 0.1))
        
        # Apply skill multiplier if using a skill
        if skill:
            damage *= skill['damage_mult']
        
        # Calculate critical hit (based on dexterity)
        crit_chance = attacker_stats['dexterity'] * 0.01
        is_crit = random.random() < crit_chance
        if is_crit:
            damage *= 1.5
        
        # Apply defense reduction (based on defender's stats)
        defense = defender_stats['strength'] * 0.5
        damage = max(1, damage - defense)  # Ensure at least 1 damage
        
        return int(damage), is_crit

    async def initiate_combat(self, ctx: commands.Context, target: discord.Member):
        """Start a combat encounter"""
        # Check if either player is already in combat
        if ctx.author.id in self.active_battles or target.id in self.active_battles:
            await ctx.send("One or both players are already in combat!")
            return
        
        # Get character data for both players
        attacker = await self.db.get_character(ctx.author.id)
        defender = await self.db.get_character(target.id)
        
        if not attacker or not defender:
            await ctx.send("Both players must have characters to engage in combat!")
            return
        
        # Convert tuples to dicts for easier access
        attacker_stats = {
            "id": attacker[0],
            "name": attacker[1],
            "class_type": attacker[2],
            "health": attacker[5],
            "max_health": attacker[6],
            "mana": attacker[7],
            "max_mana": attacker[8],
            "strength": attacker[9],
            "dexterity": attacker[10],
            "intelligence": attacker[11]
        }
        
        defender_stats = {
            "id": defender[0],
            "name": defender[1],
            "class_type": defender[2],
            "health": defender[5],
            "max_health": defender[6],
            "mana": defender[7],
            "max_mana": defender[8],
            "strength": defender[9],
            "dexterity": defender[10],
            "intelligence": defender[11]
        }
        
        # Create new battle
        battle = self.Battle(attacker_stats, defender_stats)
        self.active_battles[ctx.author.id] = battle
        self.active_battles[target.id] = battle
        
        # Create and send initial battle embed
        embed = discord.Embed(
            title="⚔️ Combat Initiated! ⚔️",
            description=f"{attacker_stats['name']} vs {defender_stats['name']}",
            color=discord.Color.red()
        )
        
        embed.add_field(
            name=f"{attacker_stats['name']} ({attacker_stats['class_type'].capitalize()})",
            value=f"HP: {attacker_stats['health']}/{attacker_stats['max_health']}\nMana: {attacker_stats['mana']}/{attacker_stats['max_mana']}",
            inline=True
        )
        
        embed.add_field(
            name=f"{defender_stats['name']} ({defender_stats['class_type'].capitalize()})",
            value=f"HP: {defender_stats['health']}/{defender_stats['max_health']}\nMana: {defender_stats['mana']}/{defender_stats['max_mana']}",
            inline=True
        )
        
        await ctx.send(embed=embed)
        
        # Start turn timer
        asyncio.create_task(self.turn_timer(ctx, battle))

    async def turn_timer(self, ctx: commands.Context, battle: Battle):
        """Handle turn timer and auto-end battle if inactive"""
        await asyncio.sleep(30)  # 30 second turn timer
        
        if battle.turn_count == 0:  # If no actions taken
            await ctx.send("Battle timed out due to inactivity!")
            await self.end_combat(ctx, battle, None)

    async def use_skill(self, ctx: commands.Context, skill_name: str, target: Optional[discord.Member] = None):
        """Use a combat skill"""
        # Check if player is in combat
        if ctx.author.id not in self.active_battles:
            await ctx.send("You are not in combat!")
            return
        
        battle = self.active_battles[ctx.author.id]
        attacker_stats = battle.player1 if battle.player1['id'] == ctx.author.id else battle.player2
        defender_stats = battle.player2 if battle.player1['id'] == ctx.author.id else battle.player1
        
        # Check if it's the player's turn
        if battle.current_turn['id'] != ctx.author.id:
            await ctx.send("It's not your turn!")
            return
        
        # Get skill data
        class_skills = self.class_skills.get(attacker_stats['class_type'].lower(), {})
        skill = class_skills.get(skill_name.lower())
        
        if not skill:
            await ctx.send(f"Invalid skill! Available skills: {', '.join(class_skills.keys())}")
            return
        
        # Check mana cost
        if attacker_stats['mana'] < skill['mana_cost']:
            await ctx.send("Not enough mana!")
            return
        
        # Calculate and apply damage
        damage, is_crit = await self.calculate_damage(attacker_stats, defender_stats, skill)
        
        # Apply special skill effects
        effect_text = ""
        if "stun_chance" in skill and random.random() < skill["stun_chance"]:
            battle.status_effects[defender_stats['id']]["stunned"] = 1
            effect_text += "\n🌟 Target is stunned for 1 turn!"
        
        if "dot_damage" in skill:
            battle.status_effects[defender_stats['id']]["poison"] = {
                "damage": skill["dot_damage"],
                "duration": skill["duration"]
            }
            effect_text += f"\n☠️ Target is poisoned for {skill['duration']} turns!"
        
        # Update stats
        new_defender_health = max(0, defender_stats['health'] - damage)
        new_attacker_mana = attacker_stats['mana'] - skill['mana_cost']
        
        await self.db.update_character(defender_stats['id'], health=new_defender_health)
        await self.db.update_character(attacker_stats['id'], mana=new_attacker_mana)
        
        # Create and send combat update embed
        embed = discord.Embed(
            title=f"⚔️ {attacker_stats['name']} used {skill_name}! ⚔️",
            description=f"Dealt {damage} damage{'! (Critical Hit!)' if is_crit else '!'}{effect_text}",
            color=discord.Color.blue()
        )
        
        embed.add_field(
            name=defender_stats['name'],
            value=f"HP: {new_defender_health}/{defender_stats['max_health']}",
            inline=True
        )
        
        await ctx.send(embed=embed)
        
        # Check for battle end
        if new_defender_health <= 0:
            await self.end_combat(ctx, battle, attacker_stats)
            return
        
        # Update turn
        battle.current_turn = defender_stats
        battle.turn_count += 1
        
        # Reset turn timer
        asyncio.create_task(self.turn_timer(ctx, battle))

    async def end_combat(self, ctx: commands.Context, battle: Battle, winner: Optional[dict]):
        """End a combat encounter and distribute rewards"""
        if winner:
            # Calculate experience and gold rewards
            exp_reward = random.randint(50, 100)
            gold_reward = random.randint(100, 200)
            
            # Award rewards to winner
            await self.db.update_character(winner['id'], experience=exp_reward)
            await self.db.update_balance(winner['id'], gold_reward)
            
            embed = discord.Embed(
                title="🏆 Combat Ended! 🏆",
                description=f"{winner['name']} is victorious!",
                color=discord.Color.gold()
            )
            
            embed.add_field(name="Experience Gained", value=exp_reward)
            embed.add_field(name="Gold Earned", value=gold_reward)
            
            await ctx.send(embed=embed)
        
        # Clean up battle data
        if battle.player1['id'] in self.active_battles:
            del self.active_battles[battle.player1['id']]
        if battle.player2['id'] in self.active_battles:
            del self.active_battles[battle.player2['id']]
