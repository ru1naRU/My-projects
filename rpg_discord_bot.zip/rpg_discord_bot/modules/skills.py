import discord
from discord.ext import commands
from typing import Dict, List

class Skill:
    def __init__(self, name: str, description: str, level: int):
        self.name = name
        self.description = description
        self.level = level

class SkillSystem:
    def __init__(self, db):
        self.db = db
        self.available_skills = {
            "warrior": [
                Skill("Heavy Strike", "A powerful strike that deals extra damage.", 1),
                Skill("Shield Block", "Block incoming damage for a turn.", 2),
                Skill("Battle Roar", "Increase attack power for a short duration.", 3)
            ],
            "archer": [
                Skill("Quick Shot", "A fast shot that deals moderate damage.", 1),
                Skill("Eagle Eye", "Increase critical hit chance for a short duration.", 2),
                Skill("Multi-Shot", "Shoot multiple arrows at once.", 3)
            ],
            "mage": [
                Skill("Fireball", "Launch a fireball that deals damage.", 1),
                Skill("Ice Shield", "Create a shield that absorbs damage.", 2),
                Skill("Arcane Blast", "Unleash a powerful arcane attack.", 3)
            ]
        }

    async def show_skills(self, ctx: commands.Context):
        """Display available skills for the user's class"""
        character = await self.db.get_character(ctx.author.id)
        if not character:
            await ctx.send("You don't have a character! Use !create_character to create one.")
            return

        class_type = character[2].lower()
        skills = self.available_skills.get(class_type, [])

        embed = discord.Embed(
            title=f"🧙 {class_type.capitalize()} Skills",
            description="Here are your available skills:",
            color=discord.Color.purple()
        )

        for skill in skills:
            embed.add_field(name=skill.name, value=skill.description, inline=False)

        await ctx.send(embed=embed)

    async def learn_skill(self, ctx: commands.Context, skill_name: str):
        """Learn a new skill"""
        character = await self.db.get_character(ctx.author.id)
        if not character:
            await ctx.send("You don't have a character! Use !create_character to create one.")
            return

        class_type = character[2].lower()
        skills = self.available_skills.get(class_type, [])
        skill_to_learn = next((s for s in skills if s.name.lower() == skill_name.lower()), None)

        if not skill_to_learn:
            await ctx.send("Skill not found! Use !skills to see available skills.")
            return

        # Check if the character already knows the skill
        existing_skills = await self.db.get_skills(ctx.author.id)
        if any(s['name'].lower() == skill_to_learn.name.lower() for s in existing_skills):
            await ctx.send("You already know this skill!")
            return

        # Add the skill to the database
        await self.db.add_skill(ctx.author.id, skill_to_learn.name, skill_to_learn.level)

        embed = discord.Embed(
            title="🎓 Skill Learned!",
            description=f"You have learned the skill: **{skill_to_learn.name}**!",
            color=discord.Color.green()
        )

        await ctx.send(embed=embed)
