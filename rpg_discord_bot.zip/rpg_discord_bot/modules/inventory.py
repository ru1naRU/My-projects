import discord
from discord.ext import commands
import json
from typing import Dict, List, Optional

class InventorySystem:
    def __init__(self, db):
        self.db = db
        self.equipment_slots = {
            "weapon": ["sword", "bow", "staff", "dagger", "axe", "spear"],
            "armor": ["armor", "robe", "leather", "chainmail", "plate"],
            "accessory": ["ring", "amulet", "charm", "bracelet"]
        }
        
        # Rarity colors for embeds
        self.rarity_colors = {
            "common": discord.Color.light_grey(),
            "uncommon": discord.Color.green(),
            "rare": discord.Color.blue(),
            "epic": discord.Color.purple(),
            "legendary": discord.Color.gold()
        }

    async def show_inventory(self, ctx: commands.Context):
        """Display user's inventory"""
        inventory = await self.db.get_inventory(ctx.author.id)
        if not inventory:
            await ctx.send("Your inventory is empty!")
            return

        embed = discord.Embed(
            title="🎒 Inventory",
            description=f"{ctx.author.display_name}'s Items",
            color=discord.Color.blue()
        )

        # Group items by type
        weapons = []
        armor = []
        accessories = []
        consumables = []

        for item in inventory:
            # Convert item tuple to dict for easier access
            item_dict = {
                "id": item[0],
                "user_id": item[1],
                "item_id": item[2],
                "quantity": item[3],
                "equipped": item[4],
                "name": item[5],
                "type": item[6],
                "rarity": item[7],
                "stats": json.loads(item[8]) if isinstance(item[8], str) else item[8]
            }

            # Create item text
            item_text = f"**{item_dict['name']}**"
            if item_dict['equipped']:
                item_text += " (Equipped)"
            if item_dict['quantity'] > 1:
                item_text += f" x{item_dict['quantity']}"
            
            # Add stats if present
            if item_dict['stats']:
                stats_text = ", ".join([f"{k}: {v}" for k, v in item_dict['stats'].items()])
                item_text += f"\n*{stats_text}*"

            # Add to appropriate category
            if item_dict['type'] == 'weapon':
                weapons.append(item_text)
            elif item_dict['type'] == 'armor':
                armor.append(item_text)
            elif item_dict['type'] == 'accessory':
                accessories.append(item_text)
            else:  # consumable
                consumables.append(item_text)

        # Add fields for each category
        if weapons:
            embed.add_field(name="⚔️ Weapons", value="\n".join(weapons), inline=False)
        if armor:
            embed.add_field(name="🛡️ Armor", value="\n".join(armor), inline=False)
        if accessories:
            embed.add_field(name="💍 Accessories", value="\n".join(accessories), inline=False)
        if consumables:
            embed.add_field(name="🧪 Consumables", value="\n".join(consumables), inline=False)

        await ctx.send(embed=embed)

    async def equip_item(self, ctx: commands.Context, item_name: str):
        """Equip an item from inventory"""
        # Get inventory
        inventory = await self.db.get_inventory(ctx.author.id)
        if not inventory:
            await ctx.send("Your inventory is empty!")
            return

        # Find the item
        target_item = None
        for item in inventory:
            if item[5].lower() == item_name.lower():  # item[5] is the name
                target_item = {
                    "id": item[0],
                    "user_id": item[1],
                    "item_id": item[2],
                    "quantity": item[3],
                    "equipped": item[4],
                    "name": item[5],
                    "type": item[6],
                    "rarity": item[7],
                    "stats": json.loads(item[8]) if isinstance(item[8], str) else item[8]
                }
                break

        if not target_item:
            await ctx.send(f"You don't have an item called '{item_name}'!")
            return

        if target_item['equipped']:
            await ctx.send(f"{target_item['name']} is already equipped!")
            return

        # Determine equipment slot
        slot = None
        for slot_name, item_types in self.equipment_slots.items():
            if any(type_name in target_item['name'].lower() for type_name in item_types):
                slot = slot_name
                break

        if not slot:
            await ctx.send("This item cannot be equipped!")
            return

        # Unequip current item in that slot if any
        async with self.db.db_name as db:
            # Find currently equipped item
            cursor = await db.execute(
                '''
                SELECT i.id, i.name 
                FROM inventory i 
                JOIN items it ON i.item_id = it.id 
                WHERE i.user_id = ? AND i.equipped = 1 AND it.type = ?
                ''',
                (ctx.author.id, target_item['type'])
            )
            current_equipped = await cursor.fetchone()

            if current_equipped:
                # Unequip current item
                await db.execute(
                    'UPDATE inventory SET equipped = 0 WHERE id = ?',
                    (current_equipped[0],)
                )

            # Equip new item
            await db.execute(
                'UPDATE inventory SET equipped = 1 WHERE id = ?',
                (target_item['id'],)
            )

            await db.commit()

        # Create success embed
        embed = discord.Embed(
            title="⚔️ Item Equipped!",
            description=f"Successfully equipped {target_item['name']}!",
            color=self.rarity_colors[target_item['rarity']]
        )

        if current_equipped:
            embed.add_field(
                name="Unequipped",
                value=current_equipped[1],
                inline=False
            )

        # Add stats to embed
        if target_item['stats']:
            stats_text = "\n".join([f"{k.capitalize()}: {v}" for k, v in target_item['stats'].items()])
            embed.add_field(name="Stats", value=stats_text, inline=False)

        await ctx.send(embed=embed)

    async def use_item(self, ctx: commands.Context, item_name: str):
        """Use a consumable item"""
        # Get inventory
        inventory = await self.db.get_inventory(ctx.author.id)
        if not inventory:
            await ctx.send("Your inventory is empty!")
            return

        # Find the item
        target_item = None
        for item in inventory:
            if item[5].lower() == item_name.lower():
                target_item = {
                    "id": item[0],
                    "user_id": item[1],
                    "item_id": item[2],
                    "quantity": item[3],
                    "name": item[5],
                    "type": item[6],
                    "stats": json.loads(item[8]) if isinstance(item[8], str) else item[8]
                }
                break

        if not target_item:
            await ctx.send(f"You don't have an item called '{item_name}'!")
            return

        if target_item['type'] != 'consumable':
            await ctx.send("This item cannot be used! Try equipping it instead.")
            return

        # Apply item effects
        character = await self.db.get_character(ctx.author.id)
        if not character:
            await ctx.send("Error: Character not found!")
            return

        char_dict = {
            "health": character[5],
            "max_health": character[6],
            "mana": character[7],
            "max_mana": character[8]
        }

        # Apply effects based on item stats
        updates = {}
        effect_text = []

        if 'heal' in target_item['stats']:
            heal_amount = target_item['stats']['heal']
            new_health = min(char_dict['max_health'], char_dict['health'] + heal_amount)
            updates['health'] = new_health
            effect_text.append(f"Restored {new_health - char_dict['health']} HP")

        if 'mana' in target_item['stats']:
            mana_amount = target_item['stats']['mana']
            new_mana = min(char_dict['max_mana'], char_dict['mana'] + mana_amount)
            updates['mana'] = new_mana
            effect_text.append(f"Restored {new_mana - char_dict['mana']} Mana")

        if not updates:
            await ctx.send("This item has no usable effects!")
            return

        # Update character and inventory
        async with self.db.db_name as db:
            # Update character stats
            update_query = 'UPDATE characters SET ' + ', '.join(f'{k} = ?' for k in updates.keys())
            update_query += ' WHERE user_id = ?'
            await db.execute(update_query, list(updates.values()) + [ctx.author.id])

            # Remove one item from inventory
            if target_item['quantity'] > 1:
                await db.execute(
                    'UPDATE inventory SET quantity = quantity - 1 WHERE id = ?',
                    (target_item['id'],)
                )
            else:
                await db.execute(
                    'DELETE FROM inventory WHERE id = ?',
                    (target_item['id'],)
                )

            await db.commit()

        # Send success message
        embed = discord.Embed(
            title="🧪 Item Used!",
            description=f"Used {target_item['name']}!\n" + "\n".join(effect_text),
            color=discord.Color.green()
        )

        await ctx.send(embed=embed)
